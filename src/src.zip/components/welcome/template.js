/**
 * Created by Tomasz Gabrysiak @ Infermedica on 08/02/2017.
 */

const template = (context) => {
  return new Promise((resolve) => {
    resolve(`
      <br/>
      <h5 class="card-title text-center">Welcome to Symptom Checker</h5>
      <br/>
      <div class="card-text">
        <p>
        Welcome to Symptom Checker! Now relax at home and do 
        self checkups for any kind of disease. This has been made as an 
        initiative to promote social distancing and so that you don't have to 
        go out of your homes for checkups. Stay home, Stay safe!
        <br/>
        <br/>
        Click on Next to continue...
        </p>
        <p>
          
        </p>
        <p>
        </p>
        <p>
          
        </p>
        <p class="text-muted small">
          
        </p>
      </div>
    `);
  });
};

export default template;
