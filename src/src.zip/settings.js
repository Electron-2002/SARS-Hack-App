const settings = {
  'app-id': 'e04277b8',
  'app-key': '0c79edcc9c88952056619be36948213f'
};

export default settings;
